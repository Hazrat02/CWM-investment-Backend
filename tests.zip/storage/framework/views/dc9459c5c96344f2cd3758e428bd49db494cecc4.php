<!DOCTYPE html>
<html >

    <head>
       
    </head>
    <body >
        <div>
            <form action="<?php echo e(route('logout')); ?>" method="POST"  >
                <?php echo csrf_field(); ?>
       gfdd
            <input type="submit" value="">
            </form>
        </div>

        </div>
    </body>
</html>
<?php /**PATH C:\Users\Hazrat\Desktop\Laravel\backed-Cpaearn-rest-API-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>