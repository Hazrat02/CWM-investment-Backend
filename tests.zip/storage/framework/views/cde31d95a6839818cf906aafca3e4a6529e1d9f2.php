<!DOCTYPE html>
<html >

    <head>
       
    </head>
    <body >
        <div>
            <form action="<?php echo e(route('logout')); ?>" method="POST"  >
                <?php echo csrf_field(); ?>
       gfdd
            <input type="submit" value="">
            </form>
        </div>

        </div>
    </body>
</html>
<?php /**PATH C:\Users\Hazrat ali\Desktop\Capitals\backend\resources\views/welcome.blade.php ENDPATH**/ ?>