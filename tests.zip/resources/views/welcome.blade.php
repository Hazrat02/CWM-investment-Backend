<!DOCTYPE html>
<html >

    <head>
       
    </head>
    <body >
        <div>
            <form action="{{route('logout')}}" method="POST"  >
                @csrf
       gfdd
            <input type="submit" value="">
            </form>
        </div>

        </div>
    </body>
</html>
